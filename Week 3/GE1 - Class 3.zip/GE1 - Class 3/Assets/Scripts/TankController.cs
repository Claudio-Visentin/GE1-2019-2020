﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TankController : MonoBehaviour
{
    public bool gamepad;
    Rigidbody rigid;
    public float speed;
    public float turn;
    public float bulletSpeed;
    public Rigidbody bullet;
    public Transform bulletspawn;


    private void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody>();
      
    }
    void Update()
    {
       
        if (!gamepad)
        {
            if (Input.GetAxis("Forward") > 0.1)
            {
                rigid.AddRelativeForce(new Vector3(-speed, 0f, 0f));
            } else if (Input.GetAxis("Forward") < -0.1)
            {
                rigid.AddRelativeForce(new Vector3(speed, 0f, 0f));
            }
            if (Input.GetAxis("Turn") > 0.1)
            {
                rigid.AddTorque(new Vector3(0f, turn, 0f));
            }
            else if (Input.GetAxis("Turn") < -0.1)
            {
                rigid.AddTorque(new Vector3(0f, -turn, 0f));
            }
            if (Input.GetButtonDown("Fire"))
            {
                StartCoroutine("Fire");

            }
        }
        if (gamepad)
        {
            if (Input.GetAxis("ForwardGamepad") > 0.01)
            {
                rigid.AddRelativeForce(new Vector3(-speed * 2, 0f, 0f));
            }
            else if (Input.GetAxis("ForwardGamepad") < -0.01)
            {
                rigid.AddRelativeForce(new Vector3(speed * 2, 0f, 0f));
            }
            if (Input.GetAxis("TurnGamepad") > 0.41)
            {
                rigid.AddTorque(new Vector3(0f, turn * 2, 0f));
            }
            else if (Input.GetAxis("TurnGamepad") < -0.41)
            {
                rigid.AddRelativeTorque(new Vector3(0f, -turn * 2, 0f));
            }
            if (Input.GetButton("FireGamepad"))
            {
                StartCoroutine("Fire");
            }
        }
    }
    IEnumerator Fire ()
    {
        Rigidbody bulletClone = (Rigidbody)Instantiate(bullet, bulletspawn.position, transform.rotation);
        bulletClone.velocity = transform.right * bulletSpeed;
        yield return new WaitForSeconds(5);
        Destroy (bulletClone.gameObject);
    }
}
