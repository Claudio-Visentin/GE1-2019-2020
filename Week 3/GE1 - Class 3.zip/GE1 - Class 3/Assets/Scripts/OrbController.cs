﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OrbController : MonoBehaviour
{
    public GameObject parent;
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            other.gameObject.GetComponent<TankController>().enabled = false;
            parent.GetComponent<Patrol>().enabled = false;
            GetComponent<RotateMe>().enabled = false;
            parent.GetComponent<TankController>().enabled = true;
        }
    }
    void OnTriggerStay(Collider other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            other.gameObject.GetComponent<TankController>().enabled = true;
            parent.GetComponent<Patrol>().enabled = true;
            GetComponent<RotateMe>().enabled = true;
            parent.GetComponent<TankController>().enabled = false;
        }
    }
}
