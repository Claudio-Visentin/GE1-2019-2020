﻿using UnityEngine;
using UnityEngine.AI;

public class Patrol : MonoBehaviour
{

    public GameObject currentpoint;
    private NavMeshAgent agent;
    Ray raycastline;
    public GameObject redsphere;
    public GameObject spawner;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        agent.autoBraking = true;
        float randomangle = Random.Range(0, 360);
        spawner.transform.parent.rotation = Quaternion.Euler(0f, randomangle, 0f);
        currentpoint = Instantiate(redsphere, spawner.transform.position, Quaternion.Euler(0f, 0f, 0f));

        agent.SetDestination(currentpoint.transform.position);
    }

    void Update()
    {

        if (!agent.pathPending && agent.remainingDistance < 0.7f)
        {
            Destroy(currentpoint);
            agent = GetComponent<NavMeshAgent>();
            agent.autoBraking = true;
            float randomangle = Random.Range(0, 360);
            spawner.transform.parent.rotation = Quaternion.Euler(0f, randomangle, 0f);
            currentpoint = Instantiate(redsphere, spawner.transform.position, Quaternion.Euler(0f, 0f, 0f));

            agent.SetDestination(currentpoint.transform.position);
        }
    }
}