# Group Composer

This Virtual Camera __Aim__ algorithm aims the camera at multiple GameObjects. Otherwise, it behaves identically to the Composer and has the same settings. If the Look At target is a [Cinemachine Target Group](CinemachineTargetGroup.html), the algorithm adjusts the FOV and the camera distance to ensure that the group of targets is framed properly.

