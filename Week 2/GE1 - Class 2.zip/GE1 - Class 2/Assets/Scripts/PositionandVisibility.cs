﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PositionandVisibility : MonoBehaviour
{
    Renderer rends;
    public Camera cam;
    public Transform redtank;

    void Start()
    {
        rends = GetComponent<Renderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if (redtank.position.z > transform.position.z)
        {
            print("Blue tank is on the back");
        } else
        {
            print("Blue tank is on the front");
        }
        if (rends.IsVisibleFrom(cam))
        {
            print("Can see blue tank");
        }
    }
}
