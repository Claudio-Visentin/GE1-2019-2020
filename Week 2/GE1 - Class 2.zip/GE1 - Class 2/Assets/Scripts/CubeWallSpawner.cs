﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeWallSpawner : MonoBehaviour
{
    public GameObject cube;

    public int wallWidth = 1;
    public int wallHeight = 10;


    void Start()
    {
        for (int x = 0; x < wallWidth; x++)
        {
            for (int y = 0; y < wallHeight; y++)
            {
                 Color cubecolor = new Color(
                  Random.Range(0f, 1f),
                  Random.Range(0f, 1f),
                  Random.Range(0f, 1f)
                  );
                GameObject block = Instantiate(cube, Vector3.zero, cube.transform.rotation) as GameObject;
                block.transform.parent = transform;
                block.transform.localPosition = new Vector3(x, y, 0);
                block.GetComponent<Renderer>().material.color = cubecolor;
            }
        }
    }
 }
