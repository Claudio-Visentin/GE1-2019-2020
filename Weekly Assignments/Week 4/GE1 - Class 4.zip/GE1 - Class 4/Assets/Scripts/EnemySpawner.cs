﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject enemyprefab;
    public bool ready = true;
    void Start()
    {
        StartCoroutine("Spawn");
    }

    IEnumerator Spawn ()
    {
        ready = false;
        Instantiate(enemyprefab, gameObject.transform);
        yield return new WaitForSeconds(1f);
        ready = true;
    }

    void Update()
    {

        if (transform.childCount < 6 && ready == true)
        {
            StartCoroutine("Spawn");
        }
    }

}
