﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyDespawner : MonoBehaviour
{
    private BoxCollider main;
    public BoxCollider turret;
    private void Awake()
    {
        main = GetComponent<BoxCollider>();
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag ("Player"))
        {
            StartCoroutine("Death");
        }
    }

    IEnumerator Death ()
    {
        turret.gameObject.AddComponent<Rigidbody>();
        transform.DetachChildren();
        yield return new WaitForSeconds(4f);
        main.enabled = false;
        turret.enabled = false;
        yield return new WaitForSeconds(7f);
        Destroy(turret.gameObject);
        Destroy(this);
    }
}
